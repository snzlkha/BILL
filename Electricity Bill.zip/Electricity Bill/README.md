# MyElectricBill
Mobile application to calculate electric used bill
